package gpa.onlineSubmit;

import java.util.ArrayList;

public class OnlineBean {
	
	
    public	ArrayList online = new ArrayList();
	
	public void setOnline(ArrayList online) {
		this.online = online;
		
	}
	public ArrayList getOnline() {
		return online;
	}

}
